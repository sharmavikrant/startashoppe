module CShop7Helper
end
