module CShop3Helper
end
