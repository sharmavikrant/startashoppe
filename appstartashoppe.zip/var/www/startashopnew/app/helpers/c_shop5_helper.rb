module CShop5Helper
end
